# -*- coding: utf-8 -*-
'''
    :codeauthor: :email:`Pedro Algarvio (pedro@algarvio.me)`
    :copyright: © 2015 by the SaltStack Team, see AUTHORS for more details.
    :license: Apache 2.0, see LICENSE for more details.


    pytest_logging.version
    ~~~~~~~~~~~~~~~~~~~~~~

    pytest logging plugin version information
'''

# Import Python Libs
from __future__ import absolute_import


__version_info__ = (2015, 11, 4)
__version__ = '{0}.{1}.{2}'.format(*__version_info__)
